#include <iostream>
#include <libusb.h>
#include <linux/uinput.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

/*

Invaluable resources:
https://www.dreamincode.net/forums/topic/148707-introduction-to-using-libusb-10/ for teaching me how to do a bulk transfer from the device in libusb
https://www.kernel.org/doc/html/v4.12/input/uinput.html for teaching me how uinput works and how to make keyboard/joystick events, and for the idea behind my send function (theirs was emit)
https://stackoverflow.com/questions/39559063/libsuinput-creating-joystick-with-more-than-one-button and https://elixir.bootlin.com/linux/latest/source/include/uapi/linux/input-event-codes.h#L364 for helping me figure out how to mess with the axes

*/

//helper function for uinput
void send(int file, int typeParam, int codeParam, int valParam){
   //make input event and set its attributes
   struct input_event inputty;
   inputty.type = typeParam;
   inputty.code = codeParam;
   inputty.value = valParam;
   //write it to the uinput file
   write(file, &inputty, sizeof(inputty));
   return;
}

int main(){
    //a new libusb session
    libusb_context* libSession = nullptr;
    //initialize session & check for errors
    if(libusb_init(&libSession) < 0){
        std::cout << "ERROR: Couldn't initialize libusb session\n";
        return 1;
    }
    
    //open the virtual joystick from chompapp
    libusb_device_handle* device = libusb_open_device_with_vid_pid(libSession, 0x9A7A, 0xBA17); // VendorID: 0x9A7A ProductID: 0xBA17
    if(device == nullptr){
        std::cout << "ERROR: Couldn't open joystick\n";
        return 1;
    }

    char* data = new char[1];
    int sizeWritten;

    if(libusb_claim_interface(device, 0) < 0){
        std::cout << "ERROR: Couldn't claim 0th interface\n";
        return 1;
    }

    //open the filepath for uinput as write only
    int uinputFile = open("/dev/uinput", O_WRONLY);
    struct uinput_setup usetup;
    //allows device to send joystick button press
    ioctl(uinputFile, UI_SET_EVBIT, EV_KEY);
    ioctl(uinputFile, UI_SET_KEYBIT, BTN_JOYSTICK);
    //allows device to send x-axis events
    ioctl(uinputFile, UI_SET_EVBIT, EV_ABS);
    ioctl(uinputFile, UI_SET_ABSBIT, ABS_X);
    //allows device to send y-axis events
    ioctl(uinputFile, UI_SET_EVBIT, EV_ABS);
    ioctl(uinputFile, UI_SET_ABSBIT, ABS_Y);

    //set up our uinput device
    memset(&usetup, 0, sizeof(usetup));
    usetup.id.vendor = 0x9A7A;
    usetup.id.product = 0xBA17;
    usetup.id.bustype = BUS_USB;
    strcpy(usetup.name, "Chompstick");
    ioctl(uinputFile, UI_DEV_SETUP, &usetup);
    ioctl(uinputFile, UI_DEV_CREATE);
   
    while(true){
        //std::cout << "Start of loop...\n";
        //Read in 1 byte from joystick
        int ret = libusb_bulk_transfer(device, (1 | LIBUSB_ENDPOINT_IN), (unsigned char*)data, 1, &sizeWritten, 0);
        if(ret == 0 && sizeWritten == 1){
            //printf("%i\n", data[0]);
            //credit to https://stackoverflow.com/questions/37487528/how-to-get-the-value-of-every-bit-of-an-unsigned-char for guiding me on bitshifting
            int bitvals[8];
            //bitvals holds the single byte of data in lil-endian
            for (int i = 0; i != 8 ; i++){
                bitvals[i] = (data[0] >> i) & 1;
                //std::cout << bitvals[i] << " is our " << i << "th bit\n";
            }
            int yaxis = 2*bitvals[1] + bitvals[0];
            int xaxis = 2*bitvals[3] + bitvals[2];
            int button = bitvals[4];
            //std::cout << "yaxis is " << yaxis << "\nxaxis is " << xaxis << "\nbutton is "<<button<<"\n";

            switch(yaxis){
                case 1:
                        send(uinputFile, EV_ABS, ABS_Y, 32767);
                        send(uinputFile, EV_SYN, SYN_REPORT, 0);
                        break;
                case 2:
                        send(uinputFile, EV_ABS, ABS_Y, 0);
                        send(uinputFile, EV_SYN, SYN_REPORT, 0);
                        break;
                case 3:
                        send(uinputFile, EV_ABS, ABS_Y, -32767);
                        send(uinputFile, EV_SYN, SYN_REPORT, 0);
                        break;
                default:
                        std::cout << "ERROR: Invalid y-axis";
                        break;
            }

            switch(xaxis){
                case 1:
                        send(uinputFile, EV_ABS, ABS_X, -32767);
                        send(uinputFile, EV_SYN, SYN_REPORT, 0);
                        break;
                case 2:
                        send(uinputFile, EV_ABS, ABS_X, 0);
                        send(uinputFile, EV_SYN, SYN_REPORT, 0);
                        break;
                case 3:
                        send(uinputFile, EV_ABS, ABS_X, 32767);
                        send(uinputFile, EV_SYN, SYN_REPORT, 0);
                        break;
                default:
                        std::cout << "ERROR: Invalid x-axis";
                        break;
            }

            switch(button){
                case 0:
                        send(uinputFile, EV_KEY, BTN_JOYSTICK, 0);
                        send(uinputFile, EV_SYN, SYN_REPORT, 0);
                        break;
                case 1:
                        send(uinputFile, EV_KEY, BTN_JOYSTICK, 1);
                        send(uinputFile, EV_SYN, SYN_REPORT, 0);
                        break;
                default:
                        std::cout << "ERROR: Invalid button";
                        break;
            }

        }
        else{
            /*if(ret != 0){
                std::cout << "ERROR: reading unsuccessful:(\n";
            }
            if(sizeWritten != 1){
                std::cout << "ERROR: reading size incorrect?:(\n";
            }*/
            //release the interface
            ret = libusb_release_interface(device, 0);
            //bug: never correctly releases interface when you quit chompapp
            /*if(ret != 0){
                std::cout << "ERROR: Couldn't release interface:(\n";
                return 1;
            }
            else{
                std::cout << "Successfully released interface!:)\n";
            }*/
            //close device
            libusb_close(device);
            //end libusb session
            libusb_exit(libSession);
            //end the uinput device
            ioctl(uinputFile, UI_DEV_DESTROY);
            //close the uinput pipe
            close(uinputFile);
            delete [] data;
            return 0;
        }
    }
   
}
